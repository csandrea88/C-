class Llist {
  constructor(){
    this.head = null;
  }
  
  walk(){
    if (this.head) {
      var walker = this.head;
      while(walker.next) {
        walker = walker.next;
      }
      return walker;
    }
  }

}
class Node {
  constructor(val){
      this.value = val;
      this.next = null;
  }
}
    
Llist.prototype.add = function(val) {    
  var NewN = new Node(val);
  if (this.head === null) {
    this.head = NewN;
  } else {
    var last = this.walk();
    last.next = NewN;
  }
}

var list1 = new Llist();
list1.add(2);
list1.add(15);
console.log(list1);
    
