using qtgdojo.Models;
using System.Collections.Generic;

namespace qtgdojo.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {
        
    }
}