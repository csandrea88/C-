using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace qtgdojo.Models
{
    public class User : BaseEntity
    {
        
    }
}