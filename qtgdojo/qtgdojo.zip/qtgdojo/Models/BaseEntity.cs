namespace qtgdojo.Models
{
    public abstract class BaseEntity { }


}