namespace Belt3CSharp.Models
{
    public abstract class BaseEntity { }


}