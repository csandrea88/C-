using Belt3CSharp.Models;
using System.Collections.Generic;

namespace Belt3CSharp.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {
        
    }
}