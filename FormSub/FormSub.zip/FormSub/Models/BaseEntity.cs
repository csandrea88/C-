namespace FormSub.Models
{
    public abstract class BaseEntity { }


}