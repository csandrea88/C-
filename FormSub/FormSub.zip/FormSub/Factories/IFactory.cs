using FormSub.Models;
using System.Collections.Generic;

namespace FormSub.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {
        
    }
}