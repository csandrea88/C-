namespace loginRegis.Models
{
    public abstract class BaseEntity { }


}