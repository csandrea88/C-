using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace loginRegis.Models
{
    public class Logreg : BaseEntity
    {
        
    }
}
